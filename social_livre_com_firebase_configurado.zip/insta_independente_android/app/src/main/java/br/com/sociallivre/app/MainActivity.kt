package br.com.sociallivre.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.functions.FirebaseFunctions

private val Ink = Color(0xFF17212B)
private val Accent = Color(0xFF6750A4)
private val Canvas = Color(0xFFF8F7FB)
private val SoftPurple = Color(0xFFE8E1F4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SocialLivreApp() }
    }
}

private data class SocialUser(
    val uid: String = "",
    val displayName: String = "Usuário",
    val handle: String = "@usuario",
    val email: String = ""
)

private data class SocialPost(
    val id: String = "",
    val uid: String = "",
    val displayName: String = "Usuário",
    val handle: String = "@usuario",
    val text: String = "",
    val createdAt: Timestamp? = null
)

private data class ChatMessage(
    val id: String = "",
    val senderId: String = "",
    val text: String = "",
    val createdAt: Timestamp? = null
)

private fun DocumentSnapshot.toSocialUser() = SocialUser(
    uid = id,
    displayName = getString("displayName") ?: "Usuário",
    handle = getString("handle") ?: "@usuario",
    email = getString("email") ?: ""
)

private fun DocumentSnapshot.toSocialPost() = SocialPost(
    id = id,
    uid = getString("uid") ?: "",
    displayName = getString("displayName") ?: "Usuário",
    handle = getString("handle") ?: "@usuario",
    text = getString("text") ?: "",
    createdAt = getTimestamp("createdAt")
)

private fun DocumentSnapshot.toChatMessage() = ChatMessage(
    id = id,
    senderId = getString("senderId") ?: "",
    text = getString("text") ?: "",
    createdAt = getTimestamp("createdAt")
)

@Composable
private fun SocialLivreApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val configured = remember { FirebaseApp.getApps(context).isNotEmpty() }
    val auth = remember { if (configured) FirebaseAuth.getInstance() else null }
    val db = remember { if (configured) FirebaseFirestore.getInstance() else null }
    var currentUid by remember { mutableStateOf(auth?.currentUser?.uid) }
    var currentUser by remember { mutableStateOf<SocialUser?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    var composeOpen by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    var selectedChat by remember { mutableStateOf<SocialUser?>(null) }
    var notice by remember { mutableStateOf("") }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { currentUid = it.currentUser?.uid }
        auth?.addAuthStateListener(listener)
        onDispose { auth?.removeAuthStateListener(listener) }
    }
    DisposableEffect(db, currentUid) {
        var registration: ListenerRegistration? = null
        if (db != null && currentUid != null) {
            registration = db.collection("users").document(currentUid!!).addSnapshotListener { snap, _ ->
                if (snap != null && snap.exists()) currentUser = snap.toSocialUser()
            }
        } else currentUser = null
        onDispose { registration?.remove() }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Accent, background = Canvas, surface = Color.White)) {
        if (!configured || auth == null || db == null) {
            FirebaseSetupScreen()
        } else if (currentUid == null) {
            AuthScreen(auth = auth, db = db, onMessage = { notice = it }, notice = notice)
        } else {
            Scaffold(
                containerColor = Canvas,
                topBar = {
                    Row(
                        Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 18.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("social livre", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                            Icon(Icons.Default.AddBox, "Nova publicação", Modifier.clickable { composeOpen = true }, tint = Ink)
                            Icon(Icons.Default.MailOutline, "Mensagens", Modifier.clickable { tab = 2 }, tint = Ink)
                        }
                    }
                },
                bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Início") })
                        NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Pessoas") })
                        NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.ChatBubbleOutline, null) }, label = { Text("Mensagens") })
                        NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Perfil") })
                    }
                }
            ) { padding ->
                Box(Modifier.padding(padding).fillMaxSize()) {
                    when (tab) {
                        0 -> FeedScreen(db, currentUid!!, onReport = { post -> reportContent(db, currentUid!!, "post", post.id, "Publicação denunciada") { notice = it } }, onBlock = { post -> blockUser(db, currentUid!!, post.uid) { notice = it } }, onDelete = { post -> db.collection("posts").document(post.id).delete().addOnSuccessListener { notice = "Publicação excluída." }.addOnFailureListener { notice = "Não foi possível excluir a publicação." } })
                        1 -> PeopleScreen(db, currentUid!!, onMessage = { selectedChat = it; tab = 2 })
                        2 -> if (selectedChat != null) ChatScreen(db, currentUid!!, selectedChat!!, onBack = { selectedChat = null })
                             else InboxScreen(db, currentUid!!, onSelect = { selectedChat = it })
                        else -> ProfileScreen(db, currentUid!!, currentUser, onSignOut = { auth.signOut(); selectedChat = null }, onNotice = { notice = it })
                    }
                }
            }
            if (composeOpen) {
                AlertDialog(
                    onDismissRequest = { composeOpen = false },
                    title = { Text("Nova publicação") },
                    text = {
                        OutlinedTextField(value = draft, onValueChange = { if (it.length <= 1000) draft = it }, label = { Text("O que você quer compartilhar?") }, minLines = 3, supportingText = { Text("${draft.length}/1000") })
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val text = draft.trim()
                            if (text.isNotEmpty()) {
                                val user = currentUser
                                db.collection("posts").add(mapOf(
                                    "uid" to currentUid,
                                    "displayName" to (user?.displayName ?: auth.currentUser?.displayName ?: "Usuário"),
                                    "handle" to (user?.handle ?: "@usuario"),
                                    "text" to text,
                                    "createdAt" to FieldValue.serverTimestamp()
                                )).addOnSuccessListener { notice = "Publicação enviada." }
                                    .addOnFailureListener { notice = "Não foi possível publicar. Confira sua conexão." }
                                draft = ""
                            }
                            composeOpen = false
                        }) { Text("Publicar") }
                    },
                    dismissButton = { TextButton(onClick = { composeOpen = false }) { Text("Cancelar") } }
                )
            }
            if (notice.isNotBlank()) {
                AlertDialog(onDismissRequest = { notice = "" }, confirmButton = { TextButton(onClick = { notice = "" }) { Text("OK") } }, text = { Text(notice) })
            }
        }
    }
}

@Composable
private fun FirebaseSetupScreen() {
    Column(Modifier.fillMaxSize().background(Canvas).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("social livre", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Accent)
        Spacer(Modifier.height(12.dp))
        Text("Falta conectar o backend Firebase", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text("Adicione o arquivo google-services.json do seu projeto Firebase em app/ e habilite Authentication por e-mail e Cloud Firestore. Depois, compile novamente. Sem essa configuração, o app não consegue criar contas nem sincronizar publicações.", color = Color.DarkGray)
    }
}

@Composable
private fun AuthScreen(auth: FirebaseAuth, db: FirebaseFirestore, onMessage: (String) -> Unit, notice: String) {
    var register by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var handle by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Color.White).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("social livre", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Accent)
        Text(if (register) "Crie sua conta" else "Entre na sua conta", color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        if (register) {
            OutlinedTextField(name, { name = it.take(40) }, label = { Text("Nome de exibição") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(handle, { handle = it.lowercase().filter { c -> c.isLetterOrDigit() || c == '_' || c == '.' }.take(20) }, label = { Text("Nome de usuário (sem @)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(8.dp))
        }
        OutlinedTextField(email, { email = it.trim() }, label = { Text("E-mail") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Senha (mínimo 8 caracteres)") }, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), singleLine = true)
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            if (busy) return@Button
            if (email.isBlank() || password.length < 8 || (register && (name.isBlank() || handle.length < 3))) {
                onMessage("Preencha os campos. A senha deve ter pelo menos 8 caracteres e o usuário, 3.")
                return@Button
            }
            busy = true
            if (register) {
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnSuccessListener { result ->
                        val uid = result.user?.uid ?: return@addOnSuccessListener
                        val cleanName = name.trim()
                        val cleanHandle = "@${handle.trim('@')}"
                        db.collection("users").document(uid).set(mapOf("uid" to uid, "displayName" to cleanName, "handle" to cleanHandle, "createdAt" to FieldValue.serverTimestamp()))
                            .addOnSuccessListener { busy = false; onMessage("Conta criada. Bem-vindo ao Social Livre!") }
                            .addOnFailureListener { busy = false; onMessage("A conta foi criada, mas não conseguimos salvar o perfil. Tente entrar novamente.") }
                    }
                    .addOnFailureListener { busy = false; onMessage(authError(it.message)) }
            } else {
                auth.signInWithEmailAndPassword(email, password)
                    .addOnSuccessListener { busy = false; onMessage("") }
                    .addOnFailureListener { busy = false; onMessage(authError(it.message)) }
            }
        }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Aguarde…" else if (register) "Criar conta" else "Entrar") }
        TextButton(onClick = { register = !register }) { Text(if (register) "Já tenho uma conta — entrar" else "Criar uma conta nova") }
        if (notice.isNotBlank()) Text(notice, color = Accent, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(12.dp))
        Text("Use respeito, não compartilhe dados pessoais de outras pessoas e denuncie conteúdo abusivo.", color = Color.Gray, fontSize = 12.sp)
    }
}

private fun authError(message: String?): String = when {
    message.orEmpty().contains("password", true) || message.orEmpty().contains("credential", true) -> "E-mail ou senha incorretos."
    message.orEmpty().contains("email", true) -> "Confira o formato do e-mail."
    message.orEmpty().contains("network", true) -> "Sem conexão. Tente novamente."
    else -> "Não foi possível concluir. Verifique os dados e tente novamente."
}

@Composable
private fun FeedScreen(db: FirebaseFirestore, uid: String, onReport: (SocialPost) -> Unit, onBlock: (SocialPost) -> Unit, onDelete: (SocialPost) -> Unit) {
    val posts = remember { mutableStateListOf<SocialPost>() }
    val blocked = remember { mutableStateListOf<String>() }
    var loading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf(false) }
    DisposableEffect(db, uid) {
        val blockRegistration = db.collection("users").document(uid).collection("blockedUsers").addSnapshotListener { snapshot, _ ->
            if (snapshot != null) { blocked.clear(); blocked.addAll(snapshot.documents.map { it.id }) }
        }
        val registration = db.collection("posts").orderBy("createdAt", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener { snapshot, error ->
                loading = false
                loadError = error != null
                if (snapshot != null) {
                    posts.clear()
                    posts.addAll(snapshot.documents.map { it.toSocialPost() })
                }
            }
        onDispose { registration.remove(); blockRegistration.remove() }
    }
    val visiblePosts = posts.filter { it.uid !in blocked }
    if (loading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    else if (loadError) Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) { Text("Não foi possível carregar o feed. Confira a conexão e as regras do Firebase.") }
    else if (visiblePosts.isEmpty()) Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) { Text("Ainda não há publicações. Toque no botão + para compartilhar a primeira!") }
    else LazyColumn(contentPadding = PaddingValues(bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Color.White).padding(16.dp)) {
                Text("Bem-vindo ao Social Livre", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
                Text("Uma comunidade para compartilhar ideias com respeito.", color = Color.Gray, fontSize = 13.sp)
            }
        }
        items(visiblePosts, key = { it.id }) { post ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(0.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(CircleShape).background(SoftPurple), contentAlignment = Alignment.Center) { Text(post.displayName.take(1).uppercase(), fontWeight = FontWeight.Bold, color = Accent) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(post.displayName, fontWeight = FontWeight.Bold, color = Ink)
                            Text(post.handle, color = Color.Gray, fontSize = 12.sp)
                        }
                        if (post.uid == uid) {
                            IconButton(onClick = { onDelete(post) }) { Icon(Icons.Default.DeleteOutline, contentDescription = "Excluir publicação", tint = Color.Gray) }
                        } else {
                            IconButton(onClick = { onReport(post) }) { Icon(Icons.Default.Flag, contentDescription = "Denunciar publicação", tint = Color.Gray) }
                            IconButton(onClick = { onBlock(post) }) { Icon(Icons.Default.Block, contentDescription = "Bloquear usuário", tint = Color.Gray) }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(post.text, color = Ink, fontSize = 16.sp)
                    Spacer(Modifier.height(10.dp))
                    LikeButton(db, uid, post.id)
                }
            }
        }
    }
}

@Composable
private fun LikeButton(db: FirebaseFirestore, uid: String, postId: String) {
    var liked by remember(postId, uid) { mutableStateOf(false) }
    var count by remember(postId) { mutableIntStateOf(0) }
    DisposableEffect(db, uid, postId) {
        val likesRef = db.collection("posts").document(postId).collection("likes")
        val likeReg = likesRef.document(uid).addSnapshotListener { snapshot, _ -> liked = snapshot?.exists() == true }
        val countReg = likesRef.addSnapshotListener { snapshot, _ -> count = snapshot?.size() ?: 0 }
        onDispose { likeReg.remove(); countReg.remove() }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "Curtir", tint = if (liked) Color(0xFFB3261E) else Ink, modifier = Modifier.clickable {
            val ref = db.collection("posts").document(postId).collection("likes").document(uid)
            if (liked) ref.delete() else ref.set(mapOf("uid" to uid, "createdAt" to FieldValue.serverTimestamp()))
        })
        Spacer(Modifier.width(7.dp))
        Text("$count curtidas", color = Ink, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun PeopleScreen(db: FirebaseFirestore, uid: String, onMessage: (SocialUser) -> Unit) {
    val users = remember { mutableStateListOf<SocialUser>() }
    var query by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    DisposableEffect(db, uid) {
        val registration = db.collection("users").orderBy("displayName").limit(100).addSnapshotListener { snapshot, e ->
            error = e != null
            if (snapshot != null) { users.clear(); users.addAll(snapshot.documents.map { it.toSocialUser() }.filter { it.uid != uid }) }
        }
        onDispose { registration.remove() }
    }
    Column(Modifier.fillMaxSize().background(Color.White).padding(16.dp)) {
        Text("Encontrar pessoas", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Buscar por nome ou @usuário") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        if (error) Text("Erro ao carregar usuários. Confira as regras do Firebase.", color = Color.Red)
        LazyColumn {
            items(users.filter { it.displayName.contains(query, true) || it.handle.contains(query, true) }, key = { it.uid }) { user ->
                Row(Modifier.fillMaxWidth().clickable { onMessage(user) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(CircleShape).background(SoftPurple), contentAlignment = Alignment.Center) { Text(user.displayName.take(1).uppercase(), color = Accent, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(user.displayName, color = Ink, fontWeight = FontWeight.SemiBold); Text(user.handle, color = Color.Gray, fontSize = 13.sp) }
                    Text("Mensagem", color = Accent, fontSize = 12.sp)
                }
                HorizontalDivider(color = Color(0xFFF0EDF4))
            }
        }
    }
}

@Composable
private fun InboxScreen(db: FirebaseFirestore, uid: String, onSelect: (SocialUser) -> Unit) {
    val conversations = remember { mutableStateListOf<List<String>>() }
    val people = remember { mutableStateMapOf<String, SocialUser>() }
    var error by remember { mutableStateOf(false) }
    DisposableEffect(db, uid) {
        val registration = db.collection("conversations").whereArrayContains("participants", uid).addSnapshotListener { snapshot, e ->
            error = e != null
            if (snapshot != null) {
                conversations.clear()
                snapshot.documents.forEach { doc ->
                    val ids = (doc.get("participants") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                    val other = ids.firstOrNull { it != uid }
                    if (other != null) {
                        conversations.add(ids)
                        db.collection("users").document(other).get().addOnSuccessListener { userDoc -> if (userDoc.exists()) people[other] = userDoc.toSocialUser() }
                    }
                }
            }
        }
        onDispose { registration.remove() }
    }
    Column(Modifier.fillMaxSize().background(Color.White).padding(16.dp)) {
        Text("Mensagens", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Escolha alguém na aba Pessoas para começar uma conversa.", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        if (error) Text("Não foi possível carregar as conversas.", color = Color.Red)
        LazyColumn {
            items(conversations.distinctBy { it.filter { id -> id != uid }.firstOrNull() }) { ids ->
                val otherId = ids.firstOrNull { it != uid }
                val user = otherId?.let { people[it] }
                if (user != null) Row(Modifier.fillMaxWidth().clickable { onSelect(user) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(CircleShape).background(SoftPurple), contentAlignment = Alignment.Center) { Text(user.displayName.take(1).uppercase(), color = Accent, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(12.dp)); Column { Text(user.displayName, color = Ink, fontWeight = FontWeight.SemiBold); Text(user.handle, color = Color.Gray, fontSize = 13.sp) }
                }
            }
        }
    }
}

@Composable
private fun ChatScreen(db: FirebaseFirestore, uid: String, other: SocialUser, onBack: () -> Unit) {
    val participants = remember(uid, other.uid) { listOf(uid, other.uid).sorted() }
    val conversationId = remember(participants) { participants.joinToString("_") }
    val messages = remember(conversationId) { mutableStateListOf<ChatMessage>() }
    var text by remember { mutableStateOf("") }
    var sendError by remember { mutableStateOf(false) }
    var conversationReady by remember(conversationId) { mutableStateOf(false) }
    LaunchedEffect(conversationId) {
        db.collection("conversations").document(conversationId)
            .set(mapOf("participants" to participants, "updatedAt" to FieldValue.serverTimestamp()), com.google.firebase.firestore.SetOptions.merge())
            .addOnSuccessListener { conversationReady = true }
            .addOnFailureListener { sendError = true }
    }
    DisposableEffect(db, conversationId) {
        val registration = db.collection("conversations").document(conversationId).collection("messages").orderBy("createdAt", Query.Direction.ASCENDING).limit(200).addSnapshotListener { snapshot, _ ->
            if (snapshot != null) { messages.clear(); messages.addAll(snapshot.documents.map { it.toChatMessage() }) }
        }
        onDispose { registration.remove() }
    }
    Column(Modifier.fillMaxSize().background(Color.White)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
            Column { Text(other.displayName, fontWeight = FontWeight.Bold, color = Ink); Text(other.handle, fontSize = 12.sp, color = Color.Gray) }
        }
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp), reverseLayout = false, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages, key = { it.id }) { message ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.senderId == uid) Arrangement.End else Arrangement.Start) {
                    Box(Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(14.dp)).background(if (message.senderId == uid) SoftPurple else Color(0xFFF1F1F1)).padding(12.dp)) { Text(message.text, color = Ink) }
                }
            }
        }
        if (sendError) Text("Não foi possível enviar a mensagem.", color = Color.Red, modifier = Modifier.padding(horizontal = 12.dp))
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { if (it.length <= 2000) text = it }, modifier = Modifier.weight(1f), placeholder = { Text("Escreva uma mensagem") }, maxLines = 4)
            IconButton(enabled = conversationReady, onClick = {
                val body = text.trim()
                if (body.isNotEmpty()) {
                    val ref = db.collection("conversations").document(conversationId)
                    ref.collection("messages").add(mapOf("senderId" to uid, "text" to body, "createdAt" to FieldValue.serverTimestamp()))
                        .addOnSuccessListener { text = ""; sendError = false }
                        .addOnFailureListener { sendError = true }
                }
            }) { Icon(Icons.Default.Send, "Enviar", tint = Accent) }
        }
    }
}

@Composable
private fun ProfileScreen(db: FirebaseFirestore, uid: String, user: SocialUser?, onSignOut: () -> Unit, onNotice: (String) -> Unit) {
    var editOpen by remember { mutableStateOf(false) }
    var name by remember(user?.displayName) { mutableStateOf(user?.displayName ?: "") }
    var handle by remember(user?.handle) { mutableStateOf(user?.handle?.removePrefix("@") ?: "") }
    var deleteConfirm by remember { mutableStateOf(false) }
    val postCount = remember { mutableIntStateOf(0) }
    DisposableEffect(db, uid) {
        val registration = db.collection("posts").whereEqualTo("uid", uid).addSnapshotListener { snap, _ -> postCount.intValue = snap?.size() ?: 0 }
        onDispose { registration.remove() }
    }
    Column(Modifier.fillMaxSize().background(Color.White).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(88.dp).clip(CircleShape).background(SoftPurple), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, modifier = Modifier.size(48.dp), tint = Accent) }
        Spacer(Modifier.height(12.dp))
        Text(user?.displayName ?: "Seu perfil", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(user?.handle ?: "@usuario", color = Color.Gray)
        Text("Perfil público", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))
        Text("${postCount.intValue} publicações", color = Ink, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { editOpen = true }) { Text("Editar perfil") }
        TextButton(onClick = onSignOut) { Text("Sair da conta") }
        TextButton(onClick = { deleteConfirm = true }, colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFB3261E))) { Text("Solicitar exclusão da conta") }
        Text("Denuncie conteúdo abusivo. Não publique informações pessoais suas ou de outras pessoas.", color = Color.Gray, fontSize = 12.sp)
    }
    if (editOpen) AlertDialog(
        onDismissRequest = { editOpen = false }, title = { Text("Editar perfil") },
        text = { Column { OutlinedTextField(name, { name = it.take(40) }, label = { Text("Nome") }); OutlinedTextField(handle, { handle = it.lowercase().filter { c -> c.isLetterOrDigit() || c == '_' || c == '.' }.take(20) }, label = { Text("Usuário") }) } },
        confirmButton = { TextButton(onClick = {
            if (name.isNotBlank() && handle.length >= 3) db.collection("users").document(uid).update(mapOf("displayName" to name.trim(), "handle" to "@${handle.trim('@')}"))
                .addOnSuccessListener { onNotice("Perfil atualizado.") }.addOnFailureListener { onNotice("Não foi possível atualizar o perfil.") }
            editOpen = false
        }) { Text("Salvar") } }, dismissButton = { TextButton(onClick = { editOpen = false }) { Text("Cancelar") } }
    )
    if (deleteConfirm) AlertDialog(
        onDismissRequest = { deleteConfirm = false }, title = { Text("Excluir conta permanentemente?") },
        text = { Text("Sua conta e os dados associados serão removidos. Essa ação não pode ser desfeita. O serviço precisa ter a função de exclusão implantada no Firebase.") },
        confirmButton = { TextButton(onClick = {
            deleteConfirm = false
            FirebaseFunctions.getInstance().getHttpsCallable("deleteMyAccount").call()
                .addOnSuccessListener { onNotice("Conta excluída."); FirebaseAuth.getInstance().signOut(); onSignOut() }
                .addOnFailureListener { onNotice("Não foi possível excluir a conta. Confirme se a função Firebase foi implantada e tente novamente.") }
        }) { Text("Excluir definitivamente", color = Color(0xFFB3261E)) } },
        dismissButton = { TextButton(onClick = { deleteConfirm = false }) { Text("Cancelar") } }
    )
}

private fun reportContent(db: FirebaseFirestore, reporterUid: String, type: String, targetId: String, reason: String, done: (String) -> Unit) {
    db.collection("reports").add(mapOf("reporterUid" to reporterUid, "targetType" to type, "targetId" to targetId, "reason" to reason, "createdAt" to FieldValue.serverTimestamp(), "status" to "open"))
        .addOnSuccessListener { done("Denúncia enviada. Obrigado por ajudar a manter a comunidade segura.") }
        .addOnFailureListener { done("Não foi possível enviar a denúncia. Tente novamente.") }
}

private fun blockUser(db: FirebaseFirestore, uid: String, targetUid: String, done: (String) -> Unit) {
    if (targetUid.isBlank() || targetUid == uid) return
    db.collection("users").document(uid).collection("blockedUsers").document(targetUid)
        .set(mapOf("uid" to targetUid, "createdAt" to FieldValue.serverTimestamp()))
        .addOnSuccessListener { done("Usuário bloqueado. As publicações dele serão ocultadas do seu feed.") }
        .addOnFailureListener { done("Não foi possível bloquear esse usuário. Tente novamente.") }
}
