# Regras específicas de ProGuard/R8 podem ser adicionadas aqui quando necessárias.
