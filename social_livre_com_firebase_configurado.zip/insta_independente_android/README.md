# Social Livre — MVP de rede social online

Projeto Android nativo em Kotlin + Jetpack Compose, preparado para usar Firebase Authentication e Cloud Firestore como backend. Este pacote contém o código-fonte e regras/configuração inicial; **não contém um projeto Firebase seu, `google-services.json`, credenciais de publicação ou um binário compilado**.

## Funcionalidades implementadas no código

- Criar conta e entrar com e-mail e senha (Firebase Authentication).
- Perfil com nome e nome de usuário; edição básica do perfil.
- Feed online com atualização em tempo real.
- Publicações de texto (até 1.000 caracteres), sincronizadas no Firestore.
- Curtidas online por usuário.
- Busca local na lista de usuários carregada do Firestore.
- Conversas individuais e mensagens de texto em tempo real.
- Denunciar publicação, bloquear usuário e ocultar as publicações de usuários bloqueados no feed.
- Excluir as próprias publicações.
- Fluxo de exclusão de conta via Cloud Function, que deve ser implantada no seu projeto Firebase.
- Regras de segurança iniciais para Firestore.

## Limitações importantes

Esta é uma primeira versão de desenvolvimento, **ainda não verificada em compilação ou em aparelho**. Não inclui publicação de fotos/vídeos, stories reais, comentários, notificações push, recuperação de senha na interface, verificação de e-mail, prevenção de spam, filtro automático de conteúdo, painel de moderação ou garantia de nome de usuário único. Denúncias precisam ser acompanhadas pelo responsável do projeto no Firebase. O bloqueio oculta publicações e as regras impedem mensagens entre contas que se bloquearam, mas ainda é necessária uma revisão de segurança completa antes de abrir o serviço ao público.

A interface e as regras não substituem testes de segurança, privacidade, acessibilidade, carga e moderação. Não publique até configurar a infraestrutura, testar com várias contas e revisar os requisitos de conteúdo gerado por usuários da Google Play.

## 1. Criar e conectar seu Firebase

1. Acesse o Firebase Console com uma conta que você controla e crie um projeto chamado `Social Livre` (ou outro nome).
2. Adicione um aplicativo **Android** com o identificador exato `br.com.sociallivre.app`.
3. Baixe o arquivo `google-services.json` fornecido pelo Firebase e coloque-o em `app/google-services.json`. Não invente esse arquivo: ele é específico do seu projeto.
4. No Firebase Authentication, ative o provedor **E-mail/senha**.
5. Crie o banco **Cloud Firestore**. Escolha a região com cuidado, porque ela não deve ser trocada facilmente depois.
6. Publique as regras deste repositório usando a Firebase CLI: `firebase deploy --only firestore:rules`.
7. Para habilitar exclusão completa de conta, instale a Firebase CLI, entre no projeto certo e execute `firebase deploy --only functions`. A implantação de Cloud Functions pode exigir que o projeto esteja no plano de faturamento indicado pelo Firebase; verifique custos e limites antes de habilitar.
8. Nunca coloque uma chave privada de servidor, senha ou arquivo de conta de serviço dentro do aplicativo Android. O `google-services.json` é a configuração do cliente Firebase; não é uma chave de conta de serviço.

## 2. Compilar e testar

- Abra a pasta do projeto no Android Studio atualizado.
- Instale Android SDK Platform 36 e use o JDK recomendado pela versão do Android Gradle Plugin.
- Sincronize o Gradle e corrija erros de compilação que aparecerem. O pacote original não tinha Gradle Wrapper e este ambiente não dispõe de Android SDK/Gradle para validar a compilação.
- Teste com pelo menos duas contas em aparelhos/emuladores diferentes: criar conta, entrar/sair, publicar, curtir/descurtir, buscar pessoas, conversar, denunciar, bloquear, excluir publicação e excluir conta.
- Verifique no Firebase Console se as regras bloqueiam leitura/escrita não autorizadas. Não use regras abertas (`allow read, write: if true`) em produção.
- Configure App Check, limites contra spam, verificação de e-mail, recuperação de senha e um processo humano de revisão das denúncias antes de convidar usuários reais.

## 3. Google Play

O app ainda **não tem `.aab` assinado, chave de assinatura, capturas finais, política de privacidade hospedada, link público de exclusão de conta nem revisão da Play Console**. A ficha inicial está em `release/FICHA_GOOGLE_PLAY.md`. A política em `release/POLITICA_DE_PRIVACIDADE_MODELO.html` é um modelo que deve ser revisado, preenchido com o contato real do responsável e publicado num URL acessível. A página de exclusão de conta está em `release/EXCLUSAO_DE_CONTA.html` e também precisa ser hospedada publicamente.

A versão Android declara `targetSdk = 36`; confira o requisito vigente no Play Console no momento do envio. A assinatura deve ser criada e guardada pelo responsável, sem compartilhar a chave privada ou senhas.
