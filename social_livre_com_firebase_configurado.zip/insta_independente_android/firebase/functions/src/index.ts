import { initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";
import { HttpsError, onCall } from "firebase-functions/v2/https";

initializeApp();
const db = getFirestore();

/** Removes the authenticated user's profile, posts, likes, conversations and reports. */
export const deleteMyAccount = onCall({ enforceAppCheck: false }, async (request) => {
  const uid = request.auth?.uid;
  if (!uid) throw new HttpsError("unauthenticated", "Entre na conta para solicitar a exclusão.");

  try {
    const postSnapshot = await db.collection("posts").where("uid", "==", uid).get();
    for (const post of postSnapshot.docs) {
      await db.recursiveDelete(post.ref);
    }

    const likesSnapshot = await db.collectionGroup("likes").where("uid", "==", uid).get();
    for (const like of likesSnapshot.docs) {
      await like.ref.delete();
    }

    const conversations = await db.collection("conversations").where("participants", "array-contains", uid).get();
    for (const conversation of conversations.docs) {
      await db.recursiveDelete(conversation.ref);
    }

    const reports = await db.collection("reports").where("reporterUid", "==", uid).get();
    for (const report of reports.docs) {
      await report.ref.delete();
    }

    const userRef = db.collection("users").doc(uid);
    await db.recursiveDelete(userRef);
    await getAuth().deleteUser(uid);
    return { ok: true };
  } catch (error) {
    console.error("deleteMyAccount failed", { uid, error });
    throw new HttpsError("internal", "Não foi possível excluir todos os dados. Tente novamente ou contate o suporte.");
  }
});
