# Ficha inicial — Google Play

**Nome:** Social Livre  
**ID do pacote:** `br.com.sociallivre.app`  
**Categoria sugerida:** Social  
**Classificação etária:** responder ao questionário real da Play Console; não presumir uma classificação.

## Descrição curta (rascunho)
Compartilhe ideias, curta publicações e converse com pessoas em uma comunidade online.

## Descrição completa (rascunho)
O Social Livre é um espaço para criar publicações de texto, acompanhar o feed, curtir conteúdos e conversar individualmente com outras contas.

**Recursos previstos nesta versão:**
- Criação de conta por e-mail e senha.
- Perfil com nome e nome de usuário.
- Publicações de texto e curtidas sincronizadas online.
- Busca básica de pessoas.
- Mensagens individuais.
- Ferramentas para denunciar publicações, bloquear contas e excluir publicações próprias.
- Opção para solicitar exclusão da conta.

O serviço exige conexão à internet e uma conta. Não publique dados pessoais sensíveis. As ferramentas de denúncia e exclusão dependem da configuração correta do backend do operador.

**Importante:** não enviar esta descrição para a loja até a compilação, os testes, a implantação Firebase, a moderação, a política de privacidade e a exclusão de conta terem sido validadas. Ajustar a descrição para refletir apenas recursos realmente testados e ativos.

## Materiais ainda necessários
- Ícone de alta resolução e ícone adaptativo.
- Capturas reais de tela do aplicativo compilado e funcionando.
- E-mail de suporte do responsável.
- Política de privacidade hospedada em URL público.
- URL público da página de exclusão de conta.
- Formulário Segurança dos dados preenchido com base nos serviços efetivamente habilitados.
- Questionário de classificação etária e declarações de conteúdo gerado por usuários.
- AAB de release assinado e testado.
