# Checklist obrigatório antes de publicar

## Infraestrutura
- [ ] `google-services.json` do projeto certo está em `app/`.
- [ ] E-mail/senha está habilitado no Firebase Authentication.
- [ ] Firestore foi criado na região escolhida.
- [ ] Regras de `firestore/firestore.rules` foram publicadas e revisadas.
- [ ] Cloud Function `deleteMyAccount` foi compilada e implantada.
- [ ] Controles de abuso, limites e monitoramento foram configurados.
- [ ] Existe um processo humano para revisar denúncias e agir sobre abuso.
- [ ] Política de privacidade e página de exclusão foram revisadas, preenchidas e hospedadas em URLs públicos.

## Teste em duas contas diferentes
- [ ] Criar conta e entrar com e-mail/senha.
- [ ] Tentar criar conta com senha curta e confirmar que o app bloqueia.
- [ ] Criar publicação na conta A e verificar que aparece na conta B.
- [ ] Curtir e descurtir nas duas contas; confirmar sincronização.
- [ ] Buscar pessoas e abrir uma conversa entre A e B.
- [ ] Enviar e receber mensagens nos dois aparelhos.
- [ ] Denunciar publicação e confirmar que o registro chega ao Firebase.
- [ ] Bloquear uma conta e confirmar que suas publicações somem do feed e que não seja possível enviar mensagens entre as contas bloqueadas.
- [ ] Excluir uma publicação própria; confirmar que a regra impede excluir publicação de outra pessoa.
- [ ] Solicitar exclusão da conta e verificar que perfil, publicações, curtidas, conversas e autenticação foram removidos.
- [ ] Testar conexão lenta/desligada, erros do servidor, rotação e reabertura do aplicativo.
- [ ] Conferir os logs do Firebase e confirmar que não há permissões indevidas.

## Segurança e Google Play
- [ ] Ativar e testar verificação de e-mail e recuperação de senha.
- [ ] Configurar Firebase App Check e proteção contra spam/abuso.
- [ ] Revisar privacidade, faixa etária, classificação de conteúdo e política de conteúdo gerado por usuários.
- [ ] Testar no Android SDK alvo e em dispositivos reais.
- [ ] Gerar AAB assinado pelo responsável e testar no canal de teste interno.
- [ ] Completar Segurança dos dados, formulário de classificação etária, ficha, ícones e capturas reais.
- [ ] Enviar para revisão no Play Console e aguardar decisão oficial.

**Estado deste pacote:** código preparado; compilação, testes reais, implantação Firebase, assinatura e publicação ainda não realizados.
